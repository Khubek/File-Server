function uploadFile() {
    const fileInput = document.getElementById('fileInput')
    const file = fileInput.files[0]
    const formData = new FormData()
    formData.append('file', file)
  
    fetch('/upload', {
      method: 'POST',
      body: formData,
    })
    .then(response => response.json())
    .then(data => {
      const uploadedFiles = document.getElementById('uploadedFiles')
      const listItem = document.createElement('li')
      listItem.textContent = data.filename
      listItem.addEventListener('click', () => {
        const shell = require('child_process').exec
        shell.exec(`explorer /select,${__dirname}/${data.filename}`)
      })
      uploadedFiles.appendChild(listItem)
    })
  }
