const express = require('express');
const app = express();
const fs = require('fs');
const path = require('path');
const PORT = 3000;
const multer = require('multer');

const upload = multer({dest: 'uploads/' });

app.post('/upload', upload.single('file'), (req, res) => {
  // req.file contains the uploaded file
  // req.body contains the entire request body
  console.log(req.file);

  // You can then use the req.file object to store the file in a database or perform other operations
  const filePath = path.join(__dirname, 'uploads', req.file.originalname);

  fs.readFile(req.file.path, (err, data) => {
    if (err) {
      console.error(err);
      return res.status(500).send({ message: 'Error reading file' });
    }

    fs.writeFile(filePath, data, (err) => {
      if (err) {
        console.error(err);
        return res.status(500).send({ message: 'Error uploading file' });
      }

      res.send({ alert: 'File uploaded successfully' });
    });
  });
});

app.use('/public', express.static(path.join(__dirname, 'public')));

app.get(["/", "/index.html"], (req, res) => {
  res.sendFile(__dirname + "/public/index.html");
})

app.get('/', (req, res) => {
    res.send(`
    <!DOCTYPE html>
    <html>
      <head>
        <title>File Server</title>
      </head>
      <body>
        <h1>Choose a file to upload:</h1>
        <input type="file" id="fileInput" />
        <button onclick="uploadFile()">Upload</button>
        <script src="/public/js/index.js"></script>
      </body>
    </html>
    `);
});

app.listen(PORT, () => {
    console.log(`File server listening at http://localhost:${PORT}`);
});
